﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ParkingManagement.Models;

[Table("ParkingSession")]
[Index("TimeIn", Name = "IX_Session_TimeIn", AllDescending = true)]
public partial class ParkingSession
{
    [Key]
    [Column("id")]
    public int Id { get; set; }

    [Column("vehicle_id")]
    public int VehicleId { get; set; }

    [Column("slot_id")]
    public int SlotId { get; set; }

    [Column("rule_id")]
    public int RuleId { get; set; }

    [Column("staff_id")]
    public int StaffId { get; set; }

    [Column("time_in")]
    public DateTime TimeIn { get; set; }

    [Column("time_out")]
    public DateTime? TimeOut { get; set; }

    [Column("fee", TypeName = "decimal(10, 0)")]
    public decimal? Fee { get; set; }

    [InverseProperty("Session")]
    public virtual Invoice? Invoice { get; set; }

    [ForeignKey("RuleId")]
    [InverseProperty("ParkingSessions")]
    public virtual PricingRule Rule { get; set; } = null!;

    [ForeignKey("SlotId")]
    [InverseProperty("ParkingSessions")]
    public virtual Slot Slot { get; set; } = null!;



    [ForeignKey("StaffId")]
    [InverseProperty("ParkingSessions")]
    public virtual AppUser Staff { get; set; } = null!;

    [ForeignKey("VehicleId")]
    [InverseProperty("ParkingSessions")]
    public virtual Vehicle Vehicle { get; set; } = null!;
}
