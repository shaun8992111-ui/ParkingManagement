﻿namespace ParkingManagement.Models
{
    public class DashboardViewModel
    {
        public int OccupiedCount { get; set; }
        public int TotalSlots { get; set; }
        public decimal RevenueToday { get; set; }
        public int ActivePasses { get; set; }

        public List<Zone> Zones { get; set; } = new();
        public int? ZoneId { get; set; }
        public List<Slot> Slots { get; set; } = new();

        public string? Plate { get; set; }
        public string? Status { get; set; }
        public string? Owner { get; set; }      // resident (cư dân) hoặc guest (vãng lai)
        public bool Special { get; set; }       // chỉ hiện xe đặc biệt
        public DateTime? Date { get; set; }
        public List<DashboardSessionRow> Sessions { get; set; } = new();
        public int Page { get; set; }
        public int TotalPages { get; set; }
        public int TotalItems { get; set; }
        public int PageSize { get; set; }
    }

    // Một dòng của bảng lượt gửi xe; OwnerName để trống nghĩa là xe vãng lai
    public record DashboardSessionRow(string Plate, string Slot, DateTime TimeIn,
                                      DateTime? TimeOut, decimal? Fee, string? OwnerName,
                                      bool IsSpecial);
}