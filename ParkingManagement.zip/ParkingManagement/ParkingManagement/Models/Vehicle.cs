﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ParkingManagement.Models;

[Table("Vehicle")]
[Index("PlateNumber", Name = "UQ_Vehicle_Plate", IsUnique = true)]
public partial class Vehicle
{
    [Key]
    [Column("id")]
    public int Id { get; set; }

    [Column("customer_id")]
    public int? CustomerId { get; set; }

    [Column("plate_number")]
    [StringLength(15)]
    [Unicode(false)]
    public string PlateNumber { get; set; } = null!;
    [Column("is_special")]
    public bool IsSpecial { get; set; }
    [Column("vehicle_type")]
    [StringLength(20)]
    [Unicode(false)]
    public string VehicleType { get; set; } = null!;

    [ForeignKey("CustomerId")]
    [InverseProperty("Vehicles")]
    public virtual Customer? Customer { get; set; }

    [InverseProperty("Vehicle")]
    public virtual ICollection<MonthlyPass> MonthlyPasses { get; set; } = new List<MonthlyPass>();

    [InverseProperty("Vehicle")]
    public virtual ICollection<ParkingSession> ParkingSessions { get; set; } = new List<ParkingSession>();
}
