﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ParkingManagement.Models;

[Table("PricingRule")]
public partial class PricingRule
{
    [Key]
    [Column("id")]
    public int Id { get; set; }

    [Column("vehicle_type")]
    [StringLength(20)]
    [Unicode(false)]
    public string VehicleType { get; set; } = null!;

    [Column("price_per_hour", TypeName = "decimal(10, 0)")]
    public decimal PricePerHour { get; set; }

    [Column("price_per_day", TypeName = "decimal(10, 0)")]
    public decimal PricePerDay { get; set; }

    [Column("is_active")]
    public bool IsActive { get; set; }

    [InverseProperty("Rule")]
    public virtual ICollection<ParkingSession> ParkingSessions { get; set; } = new List<ParkingSession>();
}
