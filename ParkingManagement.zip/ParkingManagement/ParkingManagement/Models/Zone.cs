﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ParkingManagement.Models;

[Table("Zone")]
[Index("Name", Name = "UQ_Zone_Name", IsUnique = true)]
public partial class Zone
{
    [Key]
    [Column("id")]
    public int Id { get; set; }

    [Column("name")]
    [StringLength(50)]
    public string Name { get; set; } = null!;

    [Column("vehicle_type")]
    [StringLength(20)]
    [Unicode(false)]
    public string VehicleType { get; set; } = null!;

    [InverseProperty("Zone")]
    public virtual ICollection<Slot> Slots { get; set; } = new List<Slot>();
}
