﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ParkingManagement.Models;

[Table("Slot")]
[Index("ZoneId", "Code", Name = "UQ_Slot_Zone_Code", IsUnique = true)]
public partial class Slot
{
    [Key]
    [Column("id")]
    public int Id { get; set; }

    [Column("zone_id")]
    public int ZoneId { get; set; }

    [Column("code")]
    [StringLength(10)]
    [Unicode(false)]
    public string Code { get; set; } = null!;

    [Column("status")]
    [StringLength(20)]
    [Unicode(false)]
    public string Status { get; set; } = null!;

    [InverseProperty("Slot")]
    public virtual ICollection<ParkingSession> ParkingSessions { get; set; } = new List<ParkingSession>();

    [ForeignKey("ZoneId")]
    [InverseProperty("Slots")]
    public virtual Zone Zone { get; set; } = null!;
}
