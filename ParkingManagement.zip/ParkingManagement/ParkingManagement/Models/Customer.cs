﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ParkingManagement.Models;

[Table("Customer")]
[Index("UserId", Name = "UQ_Customer_User", IsUnique = true)]
public partial class Customer
{
    [Key]
    [Column("id")]
    public int Id { get; set; }

    [Column("user_id")]
    public int UserId { get; set; }

    [Column("full_name")]
    [StringLength(100)]
    public string FullName { get; set; } = null!;

    [Column("phone")]
    [StringLength(15)]
    [Unicode(false)]
    public string? Phone { get; set; }

    [ForeignKey("UserId")]
    [InverseProperty("Customer")]
    public virtual AppUser User { get; set; } = null!;

    [InverseProperty("Customer")]
    public virtual ICollection<Vehicle> Vehicles { get; set; } = new List<Vehicle>();
}
