﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace ParkingManagement.Models;

public partial class ParkingContext : DbContext
{
    public ParkingContext()
    {
    }

    public ParkingContext(DbContextOptions<ParkingContext> options)
        : base(options)
    {
    }

    public virtual DbSet<ActivityLog> ActivityLogs { get; set; }

    public virtual DbSet<AppUser> AppUsers { get; set; }

    public virtual DbSet<Customer> Customers { get; set; }

    public virtual DbSet<Invoice> Invoices { get; set; }

    public virtual DbSet<MonthlyPass> MonthlyPasses { get; set; }

    public virtual DbSet<ParkingSession> ParkingSessions { get; set; }

    public virtual DbSet<PricingRule> PricingRules { get; set; }

    public virtual DbSet<Role> Roles { get; set; }

    public virtual DbSet<Slot> Slots { get; set; }

    public virtual DbSet<Vehicle> Vehicles { get; set; }

    public virtual DbSet<Zone> Zones { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseSqlServer("Name=ConnectionStrings:ParkingContext");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<ActivityLog>(entity =>
        {
            entity.Property(e => e.CreatedAt).HasDefaultValueSql("(sysdatetime())", "DF_Log_CreatedAt");

            entity.HasOne(d => d.User).WithMany(p => p.ActivityLogs)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Log_User");
        });

        modelBuilder.Entity<AppUser>(entity =>
        {
            entity.Property(e => e.IsActive).HasDefaultValue(true, "DF_AppUser_Active");

            entity.HasOne(d => d.Role).WithMany(p => p.AppUsers)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_AppUser_Role");
        });

        modelBuilder.Entity<Customer>(entity =>
        {
            entity.HasOne(d => d.User).WithOne(p => p.Customer)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Customer_User");
        });

        modelBuilder.Entity<Invoice>(entity =>
        {
            entity.HasIndex(e => e.SessionId, "UX_Invoice_Session")
                .IsUnique()
                .HasFilter("([session_id] IS NOT NULL)");

            entity.Property(e => e.PaidAt).HasDefaultValueSql("(sysdatetime())", "DF_Invoice_PaidAt");

            entity.HasOne(d => d.Pass).WithMany(p => p.Invoices).HasConstraintName("FK_Invoice_Pass");

            entity.HasOne(d => d.Session).WithOne(p => p.Invoice).HasConstraintName("FK_Invoice_Session");
        });

        modelBuilder.Entity<MonthlyPass>(entity =>
        {
            entity.HasOne(d => d.Vehicle).WithMany(p => p.MonthlyPasses)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Pass_Vehicle");
        });

        modelBuilder.Entity<ParkingSession>(entity =>
        {
            entity.HasIndex(e => e.SlotId, "UX_Session_OpenSlot")
                .IsUnique()
                .HasFilter("([time_out] IS NULL)");

            entity.HasIndex(e => e.VehicleId, "UX_Session_OpenVehicle")
                .IsUnique()
                .HasFilter("([time_out] IS NULL)");

            entity.Property(e => e.TimeIn).HasDefaultValueSql("(sysdatetime())", "DF_Session_TimeIn");

            entity.HasOne(d => d.Rule).WithMany(p => p.ParkingSessions)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Session_Rule");

            entity.HasOne(d => d.Slot).WithMany(p => p.ParkingSessions)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Session_Slot");

            entity.HasOne(d => d.Staff).WithMany(p => p.ParkingSessions)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Session_Staff");

            entity.HasOne(d => d.Vehicle).WithMany(p => p.ParkingSessions)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Session_Vehicle");
        });

        modelBuilder.Entity<PricingRule>(entity =>
        {
            entity.Property(e => e.IsActive).HasDefaultValue(true, "DF_Pricing_Active");
        });

        modelBuilder.Entity<Slot>(entity =>
        {
            entity.Property(e => e.Status).HasDefaultValue("Available", "DF_Slot_Status");

            entity.HasOne(d => d.Zone).WithMany(p => p.Slots)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Slot_Zone");
        });

        modelBuilder.Entity<Vehicle>(entity =>
        {
            entity.HasOne(d => d.Customer).WithMany(p => p.Vehicles).HasConstraintName("FK_Vehicle_Customer");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
