﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ParkingManagement.Models;

[Table("ActivityLog")]
[Index("CreatedAt", Name = "IX_Log_CreatedAt", AllDescending = true)]
public partial class ActivityLog
{
    [Key]
    [Column("id")]
    public int Id { get; set; }

    [Column("user_id")]
    public int UserId { get; set; }

    [Column("action")]
    [StringLength(200)]
    public string Action { get; set; } = null!;

    [Column("created_at")]
    public DateTime CreatedAt { get; set; }

    [ForeignKey("UserId")]
    [InverseProperty("ActivityLogs")]
    public virtual AppUser User { get; set; } = null!;
}
