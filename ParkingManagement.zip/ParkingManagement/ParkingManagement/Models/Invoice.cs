﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace ParkingManagement.Models;

[Table("Invoice")]
public partial class Invoice
{
    [Key]
    [Column("id")]
    public int Id { get; set; }

    [Column("session_id")]
    public int? SessionId { get; set; }

    [Column("pass_id")]
    public int? PassId { get; set; }

    [Column("amount", TypeName = "decimal(10, 0)")]
    public decimal Amount { get; set; }

    [Column("paid_at")]
    public DateTime PaidAt { get; set; }

    [ForeignKey("PassId")]
    [InverseProperty("Invoices")]
    public virtual MonthlyPass? Pass { get; set; }

    [ForeignKey("SessionId")]
    [InverseProperty("Invoice")]
    public virtual ParkingSession? Session { get; set; }
}
