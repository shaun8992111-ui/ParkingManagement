﻿using System.ComponentModel.DataAnnotations;

namespace ParkingManagement.ViewModels
{
    public class ZoneForm
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Nhập tên khu")]
        [StringLength(50, ErrorMessage = "Tên khu tối đa 50 ký tự")]
        [Display(Name = "Tên khu")]
        public string Name { get; set; } = "";

        [Required(ErrorMessage = "Chọn loại xe")]
        [RegularExpression("^(Motorbike|Car)$", ErrorMessage = "Loại xe không hợp lệ")]
        [Display(Name = "Loại xe")]
        public string VehicleType { get; set; } = "Motorbike";
    }

    public record ZoneRow(int Id, string Name, string VehicleType, int SlotCount);
}