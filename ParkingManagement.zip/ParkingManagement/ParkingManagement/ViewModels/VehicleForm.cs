﻿using System.ComponentModel.DataAnnotations;

namespace ParkingManagement.ViewModels
{
    public class VehicleForm
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Nhập biển số")]
        [StringLength(20, MinimumLength = 4, ErrorMessage = "Biển số từ 4 đến 20 ký tự")]
        [Display(Name = "Biển số")]
        public string Plate { get; set; } = "";

        [Display(Name = "Xe đặc biệt (nước ngoài, quân đội, ngoại giao...)")]
        public bool Special { get; set; }

        [Required(ErrorMessage = "Chọn loại xe")]
        [RegularExpression("^(Motorbike|Car)$", ErrorMessage = "Loại xe không hợp lệ")]
        [Display(Name = "Loại xe")]
        public string VehicleType { get; set; } = "Motorbike";

        [Display(Name = "Chủ xe")]
        public int? CustomerId { get; set; }
    }

    public record VehicleRow(int Id, string Plate, string VehicleType, string? CustomerName,
                             int SessionCount, bool HasActivePass);

    public record CustomerOption(int Id, string Name);
}