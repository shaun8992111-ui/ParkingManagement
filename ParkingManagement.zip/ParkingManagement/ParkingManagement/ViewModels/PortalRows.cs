﻿namespace ParkingManagement.ViewModels
{
    public record MyVehicleRow(int Id, string Plate, string VehicleType,
                               string? ParkedSlot, DateTime? ParkedSince, DateOnly? PassUntil);

    public record MyPassRow(int Id, string Plate, DateOnly StartDate, DateOnly EndDate);

    public record HistoryRow(string Plate, string Slot, DateTime TimeIn, DateTime? TimeOut, decimal? Fee);

    public class PortalVehiclesVm
    {
        public string FullName { get; set; } = "";
        public List<MyVehicleRow> Vehicles { get; set; } = new();
        public List<MyPassRow> Passes { get; set; } = new();
    }
}