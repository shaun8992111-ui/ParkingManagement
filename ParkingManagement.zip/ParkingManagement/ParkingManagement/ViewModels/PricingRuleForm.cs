﻿using System.ComponentModel.DataAnnotations;

namespace ParkingManagement.ViewModels
{
    public class PricingRuleForm : IValidatableObject
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Chọn loại xe")]
        [RegularExpression("^(Motorbike|Car)$", ErrorMessage = "Loại xe không hợp lệ")]
        [Display(Name = "Loại xe")]
        public string VehicleType { get; set; } = "Motorbike";

        [Range(0, 10000000, ErrorMessage = "Giá theo giờ từ 0 đến 10.000.000")]
        [Display(Name = "Giá theo giờ (đ)")]
        public decimal PricePerHour { get; set; }

        [Range(0, 10000000, ErrorMessage = "Giá theo ngày từ 0 đến 10.000.000")]
        [Display(Name = "Giá theo ngày (đ)")]
        public decimal PricePerDay { get; set; }

        [Display(Name = "Đang áp dụng")]
        public bool IsActive { get; set; } = true;

        public IEnumerable<ValidationResult> Validate(ValidationContext context)
        {
            if (PricePerDay < PricePerHour)
                yield return new ValidationResult(
                    "Giá theo ngày phải lớn hơn hoặc bằng giá theo giờ.",
                    new[] { nameof(PricePerDay) });
        }
    }

    public record PricingRuleRow(int Id, string VehicleType, decimal PricePerHour,
                                 decimal PricePerDay, bool IsActive, int UsedCount);
}