﻿using System.ComponentModel.DataAnnotations;

namespace ParkingManagement.ViewModels
{
    public class SlotForm
    {
        public int Id { get; set; }

        [Range(1, int.MaxValue, ErrorMessage = "Chọn khu đỗ")]
        [Display(Name = "Khu đỗ")]
        public int ZoneId { get; set; }

        [Required(ErrorMessage = "Nhập mã ô")]
        [StringLength(10, ErrorMessage = "Mã ô tối đa 10 ký tự")]
        [RegularExpression("^[A-Za-z0-9]+$", ErrorMessage = "Mã ô chỉ gồm chữ và số")]
        [Display(Name = "Mã ô")]
        public string Code { get; set; } = "";

        [Required(ErrorMessage = "Chọn trạng thái")]
        [RegularExpression("^(Available|Maintenance|Occupied)$", ErrorMessage = "Trạng thái không hợp lệ")]
        [Display(Name = "Trạng thái")]
        public string Status { get; set; } = "Available";
    }

    public record SlotRow(int Id, string Code, string ZoneName, string VehicleType, string Status);
}