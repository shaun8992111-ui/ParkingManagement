﻿using System.ComponentModel.DataAnnotations;

namespace ParkingManagement.ViewModels
{
    public class CustomerForm
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Nhập họ tên")]
        [StringLength(100, ErrorMessage = "Họ tên tối đa 100 ký tự")]
        [Display(Name = "Họ và tên")]
        public string FullName { get; set; } = "";

        [RegularExpression(@"^0\d{9}$", ErrorMessage = "Số điện thoại gồm 10 chữ số, bắt đầu bằng 0")]
        [Display(Name = "Số điện thoại")]
        public string? Phone { get; set; }

        [StringLength(50, MinimumLength = 4, ErrorMessage = "Tên đăng nhập từ 4 đến 50 ký tự")]
        [RegularExpression("^[A-Za-z0-9_.]+$", ErrorMessage = "Tên đăng nhập chỉ gồm chữ, số, dấu chấm, gạch dưới")]
        [Display(Name = "Tên đăng nhập")]
        public string? Username { get; set; }

        [StringLength(100, MinimumLength = 8, ErrorMessage = "Mật khẩu tối thiểu 8 ký tự")]
        [DataType(DataType.Password)]
        [Display(Name = "Mật khẩu")]
        public string? Password { get; set; }

        [Display(Name = "Tài khoản đang hoạt động")]
        public bool IsActive { get; set; } = true;
    }

    public record CustomerRow(int Id, string FullName, string? Phone, string Username,
                              bool IsActive, int VehicleCount);
}