﻿using System.ComponentModel.DataAnnotations;

namespace ParkingManagement.ViewModels
{
    public class PassForm : IValidatableObject
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Nhập biển số xe")]
        [StringLength(20, MinimumLength = 4, ErrorMessage = "Biển số từ 4 đến 20 ký tự")]
        [Display(Name = "Biển số xe")]
        public string Plate { get; set; } = "";

        [DataType(DataType.Date)]
        [Display(Name = "Từ ngày")]
        public DateOnly StartDate { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Đến ngày")]
        public DateOnly EndDate { get; set; }

        [Range(0, 100000000, ErrorMessage = "Số tiền từ 0 đến 100.000.000")]
        [Display(Name = "Số tiền thu (đ)")]
        public decimal Amount { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext context)
        {
            if (EndDate < StartDate)
                yield return new ValidationResult(
                    "Ngày kết thúc phải sau hoặc bằng ngày bắt đầu.", new[] { nameof(EndDate) });
            else if (EndDate.DayNumber - StartDate.DayNumber > 400)
                yield return new ValidationResult(
                    "Một vé tối đa 400 ngày.", new[] { nameof(EndDate) });
        }
    }

    public record PassRow(int Id, string Plate, DateOnly StartDate, DateOnly EndDate, decimal? Amount);
}