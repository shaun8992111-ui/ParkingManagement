﻿namespace ParkingManagement
{
    public class SharedResource
    {
    }
}
