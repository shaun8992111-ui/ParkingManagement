﻿namespace ParkingManagement.Services
{
    public static class FeeCalculator
    {
        // Làm tròn lên theo giờ (tối thiểu 1 giờ).
        // Mỗi trọn 24 giờ tính theo giá ngày; phần lẻ không vượt quá giá ngày.
        public static decimal Calculate(DateTime timeIn, DateTime timeOut,
                                        decimal pricePerHour, decimal pricePerDay)
        {
            var minutes = Math.Max(0, (timeOut - timeIn).TotalMinutes);
            var hours = Math.Max(1, (int)Math.Ceiling(minutes / 60.0));
            var days = hours / 24;
            var rest = hours % 24;
            return days * pricePerDay + Math.Min(rest * pricePerHour, pricePerDay);
        }
    }
}