﻿using System.Globalization;

namespace ParkingManagement.Services
{
    public static class Labels
    {
        private static readonly CultureInfo Vn = new("vi-VN");

        public static string VehicleType(string? t) => t switch
        {
            "Motorbike" => "Xe máy",
            "Car" => "Ô tô",
            "Bicycle" => "Xe đạp",
            _ => t ?? ""
        };

        public static string SlotStatus(string? s) => s switch
        {
            "Available" => "Trống",
            "Occupied" => "Có xe",
            "Maintenance" => "Bảo trì",
            _ => s ?? ""
        };

        // Lớp CSS của Bootstrap cho nhãn trạng thái
        public static string SlotBadge(string? s) => s switch
        {
            "Available" => "text-bg-success",
            "Occupied" => "text-bg-danger",
            "Maintenance" => "text-bg-warning",
            _ => "text-bg-secondary"
        };

        public static string Money(decimal v) => v.ToString("N0", Vn) + "đ";
    }
}