﻿using System.Globalization;
using Microsoft.EntityFrameworkCore;
using ParkingManagement.Models;

namespace ParkingManagement.Services
{
    public record ServiceResult(bool Ok, string Message, int? SessionId = null);

    public class CheckOutPreview
    {
        public bool Found { get; set; }
        public string Message { get; set; } = "";
        public int SessionId { get; set; }
        public string Plate { get; set; } = "";
        public string Slot { get; set; } = "";
        public DateTime TimeIn { get; set; }
        public TimeSpan Duration { get; set; }
        public decimal Fee { get; set; }
        public bool FreeByPass { get; set; }
    }

    public class ParkingService
    {
        private static readonly CultureInfo Vn = new("vi-VN");
        private readonly ParkingContext _db;

        public ParkingService(ParkingContext db) { _db = db; }

        // ===================== XE VÀO =====================
        public async Task<ServiceResult> CheckInAsync(
            string rawPlate, string vehicleType, int slotId, int staffId, bool special)
        {
            var plate = PlateHelper.Normalize(rawPlate);
            if (!PlateHelper.IsAcceptable(plate))
                return new(false, "Biển số không hợp lệ (4 đến 15 ký tự chữ và số).");

            var vehicle = await _db.Vehicles.FirstOrDefaultAsync(v => v.PlateNumber == plate);

            // Xe đã được đánh dấu đặc biệt thì không cần tick lại ở các lần sau
            var isSpecial = special || (vehicle?.IsSpecial ?? false);
            if (!isSpecial && !PlateHelper.IsStandard(plate))
                return new(false, "Biển số không đúng mẫu thường. Nếu là xe đặc biệt, hãy tick ô \"Xe đặc biệt\".");

            var slot = await _db.Slots.Include(s => s.Zone).FirstOrDefaultAsync(s => s.Id == slotId);
            if (slot == null) return new(false, "Không tìm thấy ô đỗ.");
            if (slot.Status != "Available") return new(false, "Ô này không còn trống.");
            if (slot.Zone.VehicleType != vehicleType) return new(false, "Ô này không dành cho loại xe đã chọn.");

            var rule = await _db.PricingRules.FirstOrDefaultAsync(r => r.VehicleType == vehicleType && r.IsActive);
            if (rule == null) return new(false, "Chưa có bảng giá cho loại xe này.");

            if (vehicle == null)
            {
                vehicle = new Vehicle { PlateNumber = plate, VehicleType = vehicleType, IsSpecial = isSpecial };
                _db.Vehicles.Add(vehicle);
            }
            else
            {
                if (vehicle.VehicleType != vehicleType)
                    return new(false, "Biển số này đã được ghi nhận là loại xe khác.");
                if (await _db.ParkingSessions.AnyAsync(s => s.VehicleId == vehicle.Id && s.TimeOut == null))
                    return new(false, "Xe này đang gửi trong bãi.");
                if (special && !vehicle.IsSpecial)
                    vehicle.IsSpecial = true;      // nhân viên tick thì ghi nhớ cờ cho xe
            }

            var session = new ParkingSession
            {
                Vehicle = vehicle,
                SlotId = slot.Id,
                RuleId = rule.Id,
                StaffId = staffId,
                TimeIn = DateTime.Now
            };
            _db.ParkingSessions.Add(session);
            slot.Status = "Occupied";
            _db.ActivityLogs.Add(new ActivityLog
            {
                UserId = staffId,
                Action = $"Xe vào {plate}{(isSpecial ? " (xe đặc biệt)" : "")}, ô {slot.Code}",
                CreatedAt = DateTime.Now
            });

            try
            {
                await _db.SaveChangesAsync();   // một lần lưu = một transaction
            }
            catch (DbUpdateException)
            {
                return new(false, "Không ghi được, có thể ô vừa được người khác dùng. Hãy thử lại.");
            }
            return new(true, $"Đã cho xe {PlateHelper.Format(plate)} vào ô {slot.Code}.", session.Id);
        }

        // ===================== XE RA: XEM TRƯỚC PHÍ =====================
        public async Task<CheckOutPreview> PreviewCheckOutAsync(string rawPlate)
        {
            var plate = PlateHelper.Normalize(rawPlate);
            var session = await _db.ParkingSessions.AsNoTracking()
                .Include(s => s.Vehicle).Include(s => s.Slot).Include(s => s.Rule)
                .FirstOrDefaultAsync(s => s.Vehicle.PlateNumber == plate && s.TimeOut == null);

            if (session == null)
                return new CheckOutPreview { Found = false, Message = "Không tìm thấy xe đang gửi với biển số này." };

            var now = DateTime.Now;
            var (fee, free) = await CalculateFeeAsync(session, now);
            var duration = now - session.TimeIn;
            if (duration < TimeSpan.Zero) duration = TimeSpan.Zero;

            return new CheckOutPreview
            {
                Found = true,
                SessionId = session.Id,
                Plate = plate,
                Slot = session.Slot.Code,
                TimeIn = session.TimeIn,
                Duration = duration,
                Fee = fee,
                FreeByPass = free
            };
        }

        // ===================== XE RA: THU PHÍ =====================
        public async Task<ServiceResult> CheckOutAsync(int sessionId, int staffId)
        {
            var session = await _db.ParkingSessions
                .Include(s => s.Vehicle).Include(s => s.Slot).Include(s => s.Rule)
                .FirstOrDefaultAsync(s => s.Id == sessionId);

            if (session == null) return new(false, "Không tìm thấy lượt gửi xe.");
            if (session.TimeOut != null) return new(false, "Lượt gửi xe này đã được thu phí.");

            var now = DateTime.Now;
            var (fee, _) = await CalculateFeeAsync(session, now);

            session.TimeOut = now;
            session.Fee = fee;
            if (session.Slot.Status == "Occupied") session.Slot.Status = "Available";

            _db.Invoices.Add(new Invoice { SessionId = session.Id, Amount = fee, PaidAt = now });
            _db.ActivityLogs.Add(new ActivityLog
            {
                UserId = staffId,
                Action = $"Xe ra {session.Vehicle.PlateNumber}, thu {fee.ToString("N0", Vn)}đ",
                CreatedAt = now
            });

            try
            {
                await _db.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                return new(false, "Không ghi được, lượt gửi xe này có thể vừa được xử lý. Hãy tải lại trang.");
            }

            return new(true,
                $"Đã cho xe {PlateHelper.Format(session.Vehicle.PlateNumber)} ra, thu {fee.ToString("N0", Vn)}đ.",
                session.Id);
        }

        // Vé tháng còn hạn thì miễn phí, ngược lại tính theo bảng giá đã gắn vào lượt gửi
        private async Task<(decimal Fee, bool FreeByPass)> CalculateFeeAsync(ParkingSession session, DateTime at)
        {
            var day = DateOnly.FromDateTime(at);
            var hasPass = await _db.MonthlyPasses.AnyAsync(p =>
                p.VehicleId == session.VehicleId && p.StartDate <= day && p.EndDate >= day);
            if (hasPass) return (0m, true);

            var fee = FeeCalculator.Calculate(session.TimeIn, at,
                session.Rule.PricePerHour, session.Rule.PricePerDay);
            return (fee, false);
        }
    }
}