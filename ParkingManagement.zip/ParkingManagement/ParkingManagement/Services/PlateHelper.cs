﻿using System.Text.RegularExpressions;

namespace ParkingManagement.Services
{
    public static class PlateHelper
    {
        // Chữ hoa, bỏ mọi ký tự không phải chữ hoặc số (dấu cách, chấm, gạch ngang)
        public static string Normalize(string? raw)
            => Regex.Replace((raw ?? "").ToUpperInvariant().Replace("Đ", "D"), "[^A-Z0-9]", "");

        // Biển thường: 2 số tỉnh + 1-2 chữ + 0-1 số + 4-5 số cuối
        private static readonly Regex Standard = new(@"^\d{2}[A-Z]{1,2}\d?\d{4,5}$");
        private static readonly Regex With5 = new(@"^(\d{2}[A-Z]{1,2}\d?)(\d{5})$");
        private static readonly Regex With4 = new(@"^(\d{2}[A-Z]{1,2}\d?)(\d{4})$");

        public static bool IsStandard(string normalized) => Standard.IsMatch(normalized);

        // Biển đặc biệt vẫn phải từ 4 đến 15 ký tự chữ hoặc số
        public static bool IsAcceptable(string normalized) => normalized.Length is >= 4 and <= 15;

        // Hiển thị cho dễ đọc: 29B112345 thành 29B1-12345
        public static string Format(string normalized)
        {
            var m = With5.Match(normalized);
            if (!m.Success) m = With4.Match(normalized);
            return m.Success ? m.Groups[1].Value + "-" + m.Groups[2].Value : normalized;
        }
    }
}