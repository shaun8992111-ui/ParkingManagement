﻿using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ParkingManagement.Models;
using ParkingManagement.Services;
using ParkingManagement.ViewModels;

namespace ParkingManagement.Controllers
{
    [Authorize(Roles = "Customer")]
    public class PortalController : Controller
    {
        private const int PageSize = 10;
        private readonly ParkingContext _db;

        public PortalController(ParkingContext db) { _db = db; }

        // Khách hàng ứng với tài khoản đang đăng nhập.
        // Lấy từ cookie đăng nhập, không bao giờ lấy từ đường dẫn hay form.
        private async Task<(int Id, string FullName)?> CurrentCustomerAsync()
        {
            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
            var c = await _db.Customers.AsNoTracking()
                .Where(x => x.UserId == userId)
                .Select(x => new { x.Id, x.FullName })
                .FirstOrDefaultAsync();
            return c == null ? null : (c.Id, c.FullName);
        }

        // ===================== XE CỦA TÔI =====================
        public async Task<IActionResult> Vehicles()
        {
            var me = await CurrentCustomerAsync();
            if (me == null) return View("NoProfile");

            var customerId = me.Value.Id;
            var today = DateOnly.FromDateTime(DateTime.Today);

            var vehicles = await _db.Vehicles.AsNoTracking()
                .Where(v => v.CustomerId == customerId)
                .OrderBy(v => v.PlateNumber)
                .Select(v => new MyVehicleRow(
                    v.Id, v.PlateNumber, v.VehicleType,
                    _db.ParkingSessions
                        .Where(s => s.VehicleId == v.Id && s.TimeOut == null)
                        .Select(s => s.Slot.Code).FirstOrDefault(),
                    _db.ParkingSessions
                        .Where(s => s.VehicleId == v.Id && s.TimeOut == null)
                        .Select(s => (DateTime?)s.TimeIn).FirstOrDefault(),
                    _db.MonthlyPasses
                        .Where(p => p.VehicleId == v.Id && p.StartDate <= today && p.EndDate >= today)
                        .Select(p => (DateOnly?)p.EndDate).FirstOrDefault()))
                .ToListAsync();

            var passes = await (from p in _db.MonthlyPasses.AsNoTracking()
                                join v in _db.Vehicles.AsNoTracking() on p.VehicleId equals v.Id
                                where v.CustomerId == customerId
                                orderby p.EndDate descending
                                select new MyPassRow(p.Id, v.PlateNumber, p.StartDate, p.EndDate))
                               .ToListAsync();

            return View(new PortalVehiclesVm
            {
                FullName = me.Value.FullName,
                Vehicles = vehicles,
                Passes = passes
            });
        }

        // ===================== LỊCH SỬ GỬI XE =====================
        public async Task<IActionResult> History(string? q, string? status, DateTime? date, int page = 1)
        {
            var me = await CurrentCustomerAsync();
            if (me == null) return View("NoProfile");

            var customerId = me.Value.Id;

            // Điều kiện đầu tiên và bắt buộc: chỉ các lượt của xe thuộc khách này
            var query = _db.ParkingSessions.AsNoTracking()
                .Where(s => s.Vehicle.CustomerId == customerId);

            if (!string.IsNullOrWhiteSpace(q))
            {
                var key = PlateHelper.Normalize(q);
                if (key.Length > 0)
                    query = query.Where(s => s.Vehicle.PlateNumber.Contains(key));
            }
            if (status == "open")
                query = query.Where(s => s.TimeOut == null);
            else if (status == "closed")
                query = query.Where(s => s.TimeOut != null);
            if (date.HasValue)
            {
                var d = date.Value.Date;
                query = query.Where(s => s.TimeIn >= d && s.TimeIn < d.AddDays(1));
            }

            var rows = query.OrderByDescending(s => s.TimeIn)
                .Select(s => new HistoryRow(s.Vehicle.PlateNumber, s.Slot.Code, s.TimeIn, s.TimeOut, s.Fee));

            ViewBag.Q = q;
            ViewBag.Status = status;
            ViewBag.Date = date?.ToString("yyyy-MM-dd");
            return View(await PagedList<HistoryRow>.CreateAsync(rows, page, PageSize));
        }
    }
}