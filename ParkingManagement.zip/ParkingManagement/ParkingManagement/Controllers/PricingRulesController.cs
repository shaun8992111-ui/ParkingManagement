﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ParkingManagement.Models;
using ParkingManagement.Services;
using ParkingManagement.ViewModels;

namespace ParkingManagement.Controllers
{
    public class PricingRulesController : AdminBase
    {
        public PricingRulesController(ParkingContext db) : base(db) { }

        public async Task<IActionResult> Index(string? vehicleType, bool? active, int page = 1)
        {
            var query = Db.PricingRules.AsNoTracking().AsQueryable();
            if (!string.IsNullOrWhiteSpace(vehicleType))
                query = query.Where(r => r.VehicleType == vehicleType);
            if (active.HasValue)
                query = query.Where(r => r.IsActive == active.Value);

            var rows = query.OrderBy(r => r.VehicleType).ThenByDescending(r => r.IsActive).ThenBy(r => r.Id)
                .Select(r => new PricingRuleRow(r.Id, r.VehicleType, r.PricePerHour, r.PricePerDay,
                                                r.IsActive, Db.ParkingSessions.Count(s => s.RuleId == r.Id)));

            ViewBag.VehicleType = vehicleType;
            ViewBag.Active = active;
            return View(await PagedList<PricingRuleRow>.CreateAsync(rows, page, PageSize));
        }

        // Mỗi loại xe chỉ có một bảng giá đang áp dụng
        private async Task DeactivateOthersAsync(string vehicleType, int exceptId)
        {
            var others = await Db.PricingRules
                .Where(r => r.VehicleType == vehicleType && r.IsActive && r.Id != exceptId)
                .ToListAsync();
            foreach (var o in others) o.IsActive = false;
        }

        [HttpGet]
        public IActionResult Create() => View("Form", new PricingRuleForm());

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(PricingRuleForm f)
        {
            if (!ModelState.IsValid) return View("Form", f);

            if (f.IsActive) await DeactivateOthersAsync(f.VehicleType, 0);

            Db.PricingRules.Add(new PricingRule
            {
                VehicleType = f.VehicleType,
                PricePerHour = f.PricePerHour,
                PricePerDay = f.PricePerDay,
                IsActive = f.IsActive
            });
            Audit($"Thêm bảng giá {Labels.VehicleType(f.VehicleType)}: {Labels.Money(f.PricePerHour)}/giờ, {Labels.Money(f.PricePerDay)}/ngày");
            if (!await TrySaveAsync())
            {
                ModelState.AddModelError("", "Không lưu được, vui lòng thử lại.");
                return View("Form", f);
            }
            return Done("Đã thêm bảng giá.");
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var r = await Db.PricingRules.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
            if (r == null) return NotFound();

            ViewBag.Used = await Db.ParkingSessions.AnyAsync(s => s.RuleId == id);
            return View("Form", new PricingRuleForm
            {
                Id = r.Id,
                VehicleType = r.VehicleType,
                PricePerHour = r.PricePerHour,
                PricePerDay = r.PricePerDay,
                IsActive = r.IsActive
            });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, PricingRuleForm f)
        {
            var r = await Db.PricingRules.FirstOrDefaultAsync(x => x.Id == id);
            if (r == null) return NotFound();

            f.Id = id;
            var used = await Db.ParkingSessions.AnyAsync(s => s.RuleId == id);
            ViewBag.Used = used;

            if (used && f.VehicleType != r.VehicleType)
                ModelState.AddModelError(nameof(f.VehicleType), "Bảng giá đã được dùng nên không đổi loại xe.");
            if (used && (f.PricePerHour != r.PricePerHour || f.PricePerDay != r.PricePerDay))
                ModelState.AddModelError("",
                    "Bảng giá đã dùng cho các lượt gửi xe nên không sửa giá. Hãy tạo bảng giá mới và tắt bảng giá này.");
            if (!ModelState.IsValid) return View("Form", f);

            if (f.IsActive) await DeactivateOthersAsync(f.VehicleType, id);

            r.VehicleType = f.VehicleType;
            r.PricePerHour = f.PricePerHour;
            r.PricePerDay = f.PricePerDay;
            r.IsActive = f.IsActive;
            Audit($"Sửa bảng giá #{id} ({Labels.VehicleType(f.VehicleType)}), {(f.IsActive ? "đang áp dụng" : "tắt")}");
            if (!await TrySaveAsync())
            {
                ModelState.AddModelError("", "Không lưu được, vui lòng thử lại.");
                return View("Form", f);
            }
            return Done("Đã cập nhật bảng giá.");
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var r = await Db.PricingRules.FirstOrDefaultAsync(x => x.Id == id);
            if (r == null) return NotFound();

            if (await Db.ParkingSessions.AnyAsync(s => s.RuleId == id))
                return Fail("Bảng giá này đã được dùng cho các lượt gửi xe nên không thể xóa. Hãy tắt áp dụng.");

            Db.PricingRules.Remove(r);
            Audit($"Xóa bảng giá #{id} ({Labels.VehicleType(r.VehicleType)})");
            return await TrySaveAsync() ? Done("Đã xóa bảng giá.") : Fail("Không xóa được bảng giá.");
        }
    }
}