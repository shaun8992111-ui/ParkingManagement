﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Localization;
using Microsoft.AspNetCore.Mvc;

namespace ParkingManagement.Controllers
{
    [AllowAnonymous]   // trang đăng nhập cũng cần đổi được ngôn ngữ
    public class LanguageController : Controller
    {
        // GET /Language/Set?culture=en&returnUrl=/Slots
        [HttpGet]
        public IActionResult Set(string culture, string? returnUrl = null)
        {
            if (culture != "vi" && culture != "en") culture = "vi";   // chặn giá trị lạ

            Response.Cookies.Append(
                CookieRequestCultureProvider.DefaultCookieName,
                CookieRequestCultureProvider.MakeCookieValue(new RequestCulture(culture)),
                new CookieOptions
                {
                    Expires = DateTimeOffset.UtcNow.AddYears(1),
                    IsEssential = true,
                    SameSite = SameSiteMode.Lax
                });

            if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                return LocalRedirect(returnUrl);
            return RedirectToAction("Index", "Home");
        }
    }
}