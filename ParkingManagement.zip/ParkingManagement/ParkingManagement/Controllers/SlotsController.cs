﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ParkingManagement.Models;
using ParkingManagement.Services;
using ParkingManagement.ViewModels;

namespace ParkingManagement.Controllers
{
    public class SlotsController : AdminBase
    {
        public SlotsController(ParkingContext db) : base(db) { }

        private async Task LoadZonesAsync() =>
            ViewBag.Zones = await Db.Zones.AsNoTracking().OrderBy(z => z.Name).ToListAsync();

        public async Task<IActionResult> Index(string? q, int? zoneId, string? status, int page = 1)
        {
            var query = Db.Slots.AsNoTracking().AsQueryable();
            if (!string.IsNullOrWhiteSpace(q))
            {
                var key = q.Trim();
                query = query.Where(s => s.Code.Contains(key));
            }
            if (zoneId.HasValue)
                query = query.Where(s => s.ZoneId == zoneId.Value);
            if (!string.IsNullOrWhiteSpace(status))
                query = query.Where(s => s.Status == status);

            var rows = query.OrderBy(s => s.Zone.Name).ThenBy(s => s.Code)
                .Select(s => new SlotRow(s.Id, s.Code, s.Zone.Name, s.Zone.VehicleType, s.Status));

            ViewBag.Q = q;
            ViewBag.ZoneId = zoneId;
            ViewBag.Status = status;
            await LoadZonesAsync();
            return View(await PagedList<SlotRow>.CreateAsync(rows, page, PageSize));
        }

        [HttpGet]
        public async Task<IActionResult> Create()
        {
            await LoadZonesAsync();
            return View("Form", new SlotForm());
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(SlotForm f)
        {
            f.Code = f.Code?.Trim().ToUpperInvariant() ?? "";

            if (f.Status == "Occupied")
                ModelState.AddModelError(nameof(f.Status), "Ô mới không thể ở trạng thái Có xe.");

            if (!await Db.Zones.AnyAsync(z => z.Id == f.ZoneId))
                ModelState.AddModelError(nameof(f.ZoneId), "Khu đỗ không tồn tại.");
            else if (await Db.Slots.AnyAsync(s => s.ZoneId == f.ZoneId && s.Code == f.Code))
                ModelState.AddModelError(nameof(f.Code), "Mã ô đã tồn tại trong khu này.");

            if (!ModelState.IsValid)
            {
                await LoadZonesAsync();
                return View("Form", f);
            }

            Db.Slots.Add(new Slot { ZoneId = f.ZoneId, Code = f.Code, Status = f.Status });
            Audit($"Thêm ô đỗ {f.Code}");
            if (!await TrySaveAsync())
            {
                ModelState.AddModelError("", "Không lưu được, vui lòng thử lại.");
                await LoadZonesAsync();
                return View("Form", f);
            }
            return Done("Đã thêm ô đỗ.");
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var s = await Db.Slots.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
            if (s == null) return NotFound();

            await LoadZonesAsync();
            return View("Form", new SlotForm { Id = s.Id, ZoneId = s.ZoneId, Code = s.Code, Status = s.Status });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, SlotForm f)
        {
            var s = await Db.Slots.Include(x => x.Zone).FirstOrDefaultAsync(x => x.Id == id);
            if (s == null) return NotFound();

            f.Id = id;
            f.Code = f.Code?.Trim().ToUpperInvariant() ?? "";
            var occupied = s.Status == "Occupied";

            if (occupied && (f.ZoneId != s.ZoneId || f.Status != "Occupied"))
                ModelState.AddModelError("", "Ô đang có xe: không đổi được khu đỗ và trạng thái.");
            if (!occupied && f.Status == "Occupied")
                ModelState.AddModelError(nameof(f.Status), "Trạng thái Có xe do hệ thống đặt khi xe vào.");

            var zone = await Db.Zones.FirstOrDefaultAsync(z => z.Id == f.ZoneId);
            if (zone == null)
            {
                ModelState.AddModelError(nameof(f.ZoneId), "Khu đỗ không tồn tại.");
            }
            else
            {
                if (await Db.Slots.AnyAsync(x => x.ZoneId == f.ZoneId && x.Code == f.Code && x.Id != id))
                    ModelState.AddModelError(nameof(f.Code), "Mã ô đã tồn tại trong khu này.");

                if (f.ZoneId != s.ZoneId && zone.VehicleType != s.Zone.VehicleType &&
                    await Db.ParkingSessions.AnyAsync(x => x.SlotId == id))
                    ModelState.AddModelError(nameof(f.ZoneId),
                        "Ô đã có lịch sử gửi xe nên không chuyển sang khu khác loại xe.");
            }

            if (!ModelState.IsValid)
            {
                await LoadZonesAsync();
                return View("Form", f);
            }

            s.ZoneId = f.ZoneId;
            s.Code = f.Code;
            s.Status = f.Status;
            Audit($"Sửa ô đỗ {f.Code}");
            if (!await TrySaveAsync())
            {
                ModelState.AddModelError("", "Không lưu được, vui lòng thử lại.");
                await LoadZonesAsync();
                return View("Form", f);
            }
            return Done("Đã cập nhật ô đỗ.");
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var s = await Db.Slots.FirstOrDefaultAsync(x => x.Id == id);
            if (s == null) return NotFound();

            if (await Db.ParkingSessions.AnyAsync(x => x.SlotId == id))
                return Fail("Ô này đã có lịch sử gửi xe nên không thể xóa. Hãy đặt trạng thái Bảo trì.");

            Db.Slots.Remove(s);
            Audit($"Xóa ô đỗ {s.Code}");
            return await TrySaveAsync() ? Done("Đã xóa ô đỗ.") : Fail("Không xóa được ô đỗ.");
        }
    }
}