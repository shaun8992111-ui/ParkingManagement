﻿using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ParkingManagement.Models;

namespace ParkingManagement.Controllers
{
    // Lớp cha của mọi controller quản lý dành cho Admin
    [Authorize(Roles = "Admin")]
    public abstract class AdminBase : Controller
    {
        protected const int PageSize = 10;

        protected ParkingContext Db { get; }

        protected AdminBase(ParkingContext db) { Db = db; }

        protected int CurrentUserId =>
            int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

        // Ghi nhật ký; được lưu cùng lần SaveChanges kế tiếp
        protected void Audit(string action) =>
            Db.ActivityLogs.Add(new ActivityLog
            {
                UserId = CurrentUserId,
                Action = action,
                CreatedAt = DateTime.Now
            });

        // Lưu và báo kết quả thay vì để lỗi cơ sở dữ liệu văng ra trang lỗi
        protected async Task<bool> TrySaveAsync()
        {
            try
            {
                await Db.SaveChangesAsync();
                return true;
            }
            catch (DbUpdateException)
            {
                return false;
            }
        }

        protected IActionResult Done(string message)
        {
            TempData["Success"] = message;
            return RedirectToAction("Index");
        }

        protected IActionResult Fail(string message)
        {
            TempData["Error"] = message;
            return RedirectToAction("Index");
        }
    }
}