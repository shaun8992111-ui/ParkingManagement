﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ParkingManagement.Models;
using ParkingManagement.Services;
using ParkingManagement.ViewModels;

namespace ParkingManagement.Controllers
{
    public class MonthlyPassesController : AdminBase
    {
        public MonthlyPassesController(ParkingContext db) : base(db) { }

        public async Task<IActionResult> Index(string? q, string? status, int page = 1)
        {
            var today = DateOnly.FromDateTime(DateTime.Today);
            var soon = today.AddDays(7);

            var query = from p in Db.MonthlyPasses.AsNoTracking()
                        join v in Db.Vehicles.AsNoTracking() on p.VehicleId equals v.Id
                        select new { p, v };

            if (!string.IsNullOrWhiteSpace(q))
            {
                var key = PlateHelper.Normalize(q);
                if (key.Length > 0)
                    query = query.Where(x => x.v.PlateNumber.Contains(key));
            }

            switch (status)
            {
                case "active":
                    query = query.Where(x => x.p.StartDate <= today && x.p.EndDate >= today);
                    break;
                case "expiring":
                    query = query.Where(x => x.p.EndDate >= today && x.p.EndDate <= soon);
                    break;
                case "expired":
                    query = query.Where(x => x.p.EndDate < today);
                    break;
                case "upcoming":
                    query = query.Where(x => x.p.StartDate > today);
                    break;
            }

            var rows = query.OrderByDescending(x => x.p.EndDate)
                .Select(x => new PassRow(
                    x.p.Id, x.v.PlateNumber, x.p.StartDate, x.p.EndDate,
                    Db.Invoices.Where(i => i.PassId == x.p.Id)
                               .Select(i => (decimal?)i.Amount).FirstOrDefault()));

            ViewBag.Q = q;
            ViewBag.Status = status;
            return View(await PagedList<PassRow>.CreateAsync(rows, page, PageSize));
        }

        [HttpGet]
        public IActionResult Create(string? plate, DateOnly? start)
        {
            var s = start ?? DateOnly.FromDateTime(DateTime.Today);
            return View("Form", new PassForm
            {
                Plate = plate ?? "",
                StartDate = s,
                EndDate = s.AddMonths(1).AddDays(-1)
            });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(PassForm f)
        {
            var plate = PlateHelper.Normalize(f.Plate);
            var vehicle = await Db.Vehicles.FirstOrDefaultAsync(x => x.PlateNumber == plate);

            if (vehicle == null)
            {
                ModelState.AddModelError(nameof(f.Plate), "Chưa có xe với biển số này. Hãy thêm xe ở mục Xe trước.");
            }
            else if (await Db.MonthlyPasses.AnyAsync(p => p.VehicleId == vehicle.Id
                         && p.StartDate <= f.EndDate && p.EndDate >= f.StartDate))
            {
                ModelState.AddModelError("",
                    "Xe đã có vé tháng trùng thời gian này. Muốn gia hạn, hãy bắt đầu sau ngày kết thúc của vé hiện tại.");
            }
            if (!ModelState.IsValid) return View("Form", f);

            var pass = new MonthlyPass
            {
                VehicleId = vehicle!.Id,
                StartDate = f.StartDate,
                EndDate = f.EndDate
            };

            await using var tx = await Db.Database.BeginTransactionAsync();
            try
            {
                Db.MonthlyPasses.Add(pass);
                await Db.SaveChangesAsync();

                Db.Invoices.Add(new Invoice { PassId = pass.Id, Amount = f.Amount, PaidAt = DateTime.Now });
                Audit($"Thêm vé tháng {plate} ({f.StartDate:dd/MM/yyyy} đến {f.EndDate:dd/MM/yyyy}), thu {Labels.Money(f.Amount)}");
                await Db.SaveChangesAsync();
                await tx.CommitAsync();
            }
            catch (DbUpdateException)
            {
                ModelState.AddModelError("", "Không lưu được, vui lòng thử lại.");
                return View("Form", f);
            }
            return Done("Đã thêm vé tháng và ghi hóa đơn.");
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var row = await (from p in Db.MonthlyPasses.AsNoTracking()
                             join v in Db.Vehicles.AsNoTracking() on p.VehicleId equals v.Id
                             where p.Id == id
                             select new { p, v.PlateNumber }).FirstOrDefaultAsync();
            if (row == null) return NotFound();

            var amount = await Db.Invoices.Where(i => i.PassId == id)
                .Select(i => (decimal?)i.Amount).FirstOrDefaultAsync();

            return View("Form", new PassForm
            {
                Id = row.p.Id,
                Plate = PlateHelper.Format(row.PlateNumber),
                StartDate = row.p.StartDate,
                EndDate = row.p.EndDate,
                Amount = amount ?? 0
            });
        }

        // Chỉ cho đổi ngày kết thúc
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, PassForm f)
        {
            var p = await Db.MonthlyPasses.FirstOrDefaultAsync(x => x.Id == id);
            if (p == null) return NotFound();

            var plate = await Db.Vehicles.Where(v => v.Id == p.VehicleId)
                .Select(v => v.PlateNumber).FirstAsync();

            f.Id = id;
            f.Plate = PlateHelper.Format(plate);
            f.StartDate = p.StartDate;      // không cho đổi

            if (f.EndDate < p.StartDate)
                ModelState.AddModelError(nameof(f.EndDate), "Ngày kết thúc phải sau hoặc bằng ngày bắt đầu.");
            else if (await Db.MonthlyPasses.AnyAsync(x => x.Id != id && x.VehicleId == p.VehicleId
                         && x.StartDate <= f.EndDate && x.EndDate >= p.StartDate))
                ModelState.AddModelError(nameof(f.EndDate), "Khoảng ngày này trùng với một vé tháng khác của xe.");

            if (!ModelState.IsValid) return View("Form", f);

            p.EndDate = f.EndDate;
            Audit($"Sửa vé tháng {plate}: ngày kết thúc {f.EndDate:dd/MM/yyyy}");
            if (!await TrySaveAsync())
            {
                ModelState.AddModelError("", "Không lưu được, vui lòng thử lại.");
                return View("Form", f);
            }
            return Done("Đã cập nhật ngày kết thúc vé tháng.");
        }
    }
}