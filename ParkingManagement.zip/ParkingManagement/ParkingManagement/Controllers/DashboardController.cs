﻿using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ParkingManagement.Models;
using ParkingManagement.Services;

namespace ParkingManagement.Controllers
{
    [Authorize(Roles = "Admin")]
    public class DashboardController : Controller
    {
        private const int PageSize = 10;
        private const int ExportLimit = 5000;
        private readonly ParkingContext _db;

        public DashboardController(ParkingContext db) { _db = db; }

        // Bộ lọc dùng chung cho trang Tổng quan và xuất CSV
        private static IQueryable<ParkingSession> ApplyFilters(
            IQueryable<ParkingSession> q, string? plate, string? status,
            string? owner, bool special, DateTime? date)
        {
            if (!string.IsNullOrWhiteSpace(plate))
            {
                var key = PlateHelper.Normalize(plate);
                if (key.Length > 0)
                    q = q.Where(s => s.Vehicle.PlateNumber.Contains(key));
            }
            if (status == "open")
                q = q.Where(s => s.TimeOut == null);
            else if (status == "closed")
                q = q.Where(s => s.TimeOut != null);

            if (owner == "resident")
                q = q.Where(s => s.Vehicle.CustomerId != null);
            else if (owner == "guest")
                q = q.Where(s => s.Vehicle.CustomerId == null);

            if (special)
                q = q.Where(s => s.Vehicle.IsSpecial);

            if (date.HasValue)
            {
                var d = date.Value.Date;
                q = q.Where(s => s.TimeIn >= d && s.TimeIn < d.AddDays(1));
            }
            return q;
        }

        // Chuyển lượt gửi xe thành dòng hiển thị, kèm tên chủ xe (nếu có) và cờ xe đặc biệt
        private IQueryable<DashboardSessionRow> ToRows(IQueryable<ParkingSession> q) =>
            q.Select(s => new DashboardSessionRow(
                s.Vehicle.PlateNumber,
                s.Slot.Code,
                s.TimeIn,
                s.TimeOut,
                s.Fee,
                _db.Customers.Where(c => c.Id == s.Vehicle.CustomerId)
                             .Select(c => c.FullName).FirstOrDefault(),
                s.Vehicle.IsSpecial));

        public async Task<IActionResult> Index(
            int? zoneId, string? plate, string? status, string? owner,
            bool special, DateTime? date, int page = 1)
        {
            var today = DateTime.Today;
            var todayDate = DateOnly.FromDateTime(today);

            var zones = await _db.Zones.AsNoTracking().OrderBy(z => z.Name).ToListAsync();
            var currentZoneId = zoneId ?? zones.FirstOrDefault()?.Id;

            var query = ApplyFilters(_db.ParkingSessions.AsNoTracking(), plate, status, owner, special, date);

            var total = await query.CountAsync();
            var totalPages = Math.Max(1, (int)Math.Ceiling(total / (double)PageSize));
            page = Math.Clamp(page, 1, totalPages);

            var vm = new DashboardViewModel
            {
                OccupiedCount = await _db.ParkingSessions.CountAsync(s => s.TimeOut == null),
                TotalSlots = await _db.Slots.CountAsync(),
                RevenueToday = await _db.Invoices
                    .Where(i => i.PaidAt >= today && i.PaidAt < today.AddDays(1))
                    .SumAsync(i => (decimal?)i.Amount) ?? 0,
                ActivePasses = await _db.MonthlyPasses
                    .CountAsync(p => p.StartDate <= todayDate && p.EndDate >= todayDate),

                Zones = zones,
                ZoneId = currentZoneId,
                Slots = await _db.Slots.AsNoTracking().Where(s => s.ZoneId == currentZoneId)
                    .OrderBy(s => s.Code).ToListAsync(),

                Plate = plate,
                Status = status,
                Owner = owner,
                Special = special,
                Date = date,
                Sessions = await ToRows(query.OrderByDescending(s => s.TimeIn)
                        .Skip((page - 1) * PageSize).Take(PageSize))
                    .ToListAsync(),
                Page = page,
                TotalPages = totalPages,
                TotalItems = total,
                PageSize = PageSize
            };
            return View(vm);
        }

        // Xuất danh sách lượt gửi xe đang lọc ra CSV (mở được bằng Excel)
        public async Task<IActionResult> Export(
            string? plate, string? status, string? owner, bool special, DateTime? date)
        {
            var query = ApplyFilters(_db.ParkingSessions.AsNoTracking(), plate, status, owner, special, date);
            var rows = await ToRows(query.OrderByDescending(s => s.TimeIn).Take(ExportLimit))
                .ToListAsync();

            var sb = new StringBuilder();
            sb.AppendLine("Biển số,Chủ xe,Xe đặc biệt,Ô,Giờ vào,Giờ ra,Phí (đ)");
            foreach (var r in rows)
            {
                sb.AppendLine(string.Join(",",
                    Csv(PlateHelper.Format(r.Plate)),
                    Csv(r.OwnerName ?? "Vãng lai"),
                    Csv(r.IsSpecial ? "Có" : "Không"),
                    Csv(r.Slot),
                    Csv(r.TimeIn.ToString("yyyy-MM-dd HH:mm")),
                    Csv(r.TimeOut?.ToString("yyyy-MM-dd HH:mm") ?? "Đang gửi"),
                    Csv(r.Fee?.ToString("0") ?? "")));
            }

            // BOM để Excel đọc đúng tiếng Việt có dấu
            var bytes = Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(sb.ToString())).ToArray();
            return File(bytes, "text/csv; charset=utf-8", $"luot-gui-xe-{DateTime.Now:yyyyMMdd-HHmm}.csv");
        }

        // Bọc dấu nháy; chặn ô bắt đầu bằng = + - @ để Excel không hiểu là công thức
        private static string Csv(string? value)
        {
            value ??= "";
            if (value.Length > 0 && "=+-@".Contains(value[0])) value = "'" + value;
            return "\"" + value.Replace("\"", "\"\"") + "\"";
        }
    }
}