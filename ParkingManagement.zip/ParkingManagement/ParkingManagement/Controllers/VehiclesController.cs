﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ParkingManagement.Models;
using ParkingManagement.Services;
using ParkingManagement.ViewModels;

namespace ParkingManagement.Controllers
{
    public class VehiclesController : AdminBase
    {
        public VehiclesController(ParkingContext db) : base(db) { }

        private async Task LoadCustomersAsync() =>
            ViewBag.Customers = await Db.Customers.AsNoTracking()
                .OrderBy(c => c.FullName)
                .Select(c => new CustomerOption(c.Id, c.FullName))
                .ToListAsync();

        public async Task<IActionResult> Index(string? q, string? vehicleType, string? owner, int page = 1)
        {
            var today = DateOnly.FromDateTime(DateTime.Today);

            var query = Db.Vehicles.AsNoTracking().AsQueryable();
            if (!string.IsNullOrWhiteSpace(q))
            {
                var key = PlateHelper.Normalize(q);
                if (key.Length > 0)
                    query = query.Where(v => v.PlateNumber.Contains(key));
            }
            if (!string.IsNullOrWhiteSpace(vehicleType))
                query = query.Where(v => v.VehicleType == vehicleType);
            if (owner == "has")
                query = query.Where(v => v.CustomerId != null);
            else if (owner == "none")
                query = query.Where(v => v.CustomerId == null);

            var rows = query.OrderBy(v => v.PlateNumber)
                .Select(v => new VehicleRow(
                    v.Id, v.PlateNumber, v.VehicleType,
                    Db.Customers.Where(c => c.Id == v.CustomerId).Select(c => c.FullName).FirstOrDefault(),
                    Db.ParkingSessions.Count(s => s.VehicleId == v.Id),
                    Db.MonthlyPasses.Any(p => p.VehicleId == v.Id
                                              && p.StartDate <= today && p.EndDate >= today)));

            ViewBag.Q = q;
            ViewBag.VehicleType = vehicleType;
            ViewBag.Owner = owner;
            return View(await PagedList<VehicleRow>.CreateAsync(rows, page, PageSize));
        }

        // Kiểm tra dùng chung cho thêm và sửa
        private async Task ValidateAsync(VehicleForm f, string plate, int excludeId)
        {
            if (!PlateHelper.IsAcceptable(plate))
                ModelState.AddModelError(nameof(f.Plate), "Biển số không hợp lệ (4 đến 15 ký tự chữ và số, bỏ dấu cách và gạch).");
            else if (!f.Special && !PlateHelper.IsStandard(plate))
                ModelState.AddModelError(nameof(f.Plate), "Biển số không đúng mẫu thường. Nếu là biển đặc biệt, hãy tick ô bên dưới.");

            if (plate.Length > 0 && await Db.Vehicles.AnyAsync(v => v.PlateNumber == plate && v.Id != excludeId))
                ModelState.AddModelError(nameof(f.Plate), "Biển số này đã có trong hệ thống.");

            if (f.CustomerId.HasValue && !await Db.Customers.AnyAsync(c => c.Id == f.CustomerId.Value))
                ModelState.AddModelError(nameof(f.CustomerId), "Chủ xe không tồn tại.");
        }

        [HttpGet]
        public async Task<IActionResult> Create()
        {
            await LoadCustomersAsync();
            return View("Form", new VehicleForm());
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(VehicleForm f)
        {
            var plate = PlateHelper.Normalize(f.Plate);
            await ValidateAsync(f, plate, 0);
            if (!ModelState.IsValid)
            {
                await LoadCustomersAsync();
                return View("Form", f);
            }

           Db.Vehicles.Add(new Vehicle
            {
            PlateNumber = plate,
            VehicleType = f.VehicleType,
            CustomerId = f.CustomerId,
            IsSpecial = f.Special
            });
            Audit($"Thêm xe {plate}");
            if (!await TrySaveAsync())
            {
                ModelState.AddModelError("", "Không lưu được, vui lòng thử lại.");
                await LoadCustomersAsync();
                return View("Form", f);
            }
            return Done("Đã thêm xe.");
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var v = await Db.Vehicles.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
            if (v == null) return NotFound();

            await LoadCustomersAsync();
            return View("Form", new VehicleForm
            {
                Id = v.Id,
                Plate = PlateHelper.Format(v.PlateNumber),
                Special = v.IsSpecial,
                VehicleType = v.VehicleType,
                CustomerId = v.CustomerId
            });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, VehicleForm f)
        {
            var v = await Db.Vehicles.FirstOrDefaultAsync(x => x.Id == id);
            if (v == null) return NotFound();

            f.Id = id;
            var plate = PlateHelper.Normalize(f.Plate);
            await ValidateAsync(f, plate, id);

            var changedPlate = plate != v.PlateNumber;
            var changedType = f.VehicleType != v.VehicleType;
            if (changedPlate || changedType)
            {
                if (await Db.ParkingSessions.AnyAsync(s => s.VehicleId == id && s.TimeOut == null))
                    ModelState.AddModelError("", "Xe đang gửi trong bãi nên chưa đổi được biển số hoặc loại xe.");
                if (changedType && await Db.ParkingSessions.AnyAsync(s => s.VehicleId == id))
                    ModelState.AddModelError(nameof(f.VehicleType), "Xe đã có lịch sử gửi xe nên không đổi loại xe.");
            }

            if (!ModelState.IsValid)
            {
                await LoadCustomersAsync();
                return View("Form", f);
            }

            var oldPlate = v.PlateNumber;
            v.PlateNumber = plate;
            v.VehicleType = f.VehicleType;
            v.IsSpecial = f.Special;
            Audit(changedPlate ? $"Sửa xe {oldPlate} thành {plate}" : $"Sửa xe {plate}");
            if (!await TrySaveAsync())
            {
                ModelState.AddModelError("", "Không lưu được, vui lòng thử lại.");
                await LoadCustomersAsync();
                return View("Form", f);
            }
            return Done("Đã cập nhật xe.");
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var v = await Db.Vehicles.FirstOrDefaultAsync(x => x.Id == id);
            if (v == null) return NotFound();

            if (await Db.ParkingSessions.AnyAsync(s => s.VehicleId == id)
                || await Db.MonthlyPasses.AnyAsync(p => p.VehicleId == id))
                return Fail("Xe này đã có lịch sử gửi xe hoặc vé tháng nên không thể xóa.");

            Db.Vehicles.Remove(v);
            Audit($"Xóa xe {v.PlateNumber}");
            return await TrySaveAsync() ? Done("Đã xóa xe.") : Fail("Không xóa được xe.");
        }
    }
}