﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ParkingManagement.Models;
using ParkingManagement.Services;
using ParkingManagement.ViewModels;

namespace ParkingManagement.Controllers
{
    public class CustomersController : AdminBase
    {
        private readonly PasswordHasher<AppUser> _hasher = new();

        public CustomersController(ParkingContext db) : base(db) { }

        public async Task<IActionResult> Index(string? q, bool? active, int page = 1)
        {
            var query = from c in Db.Customers.AsNoTracking()
                        join u in Db.AppUsers.AsNoTracking() on c.UserId equals u.Id
                        select new { c, u };

            if (!string.IsNullOrWhiteSpace(q))
            {
                var key = q.Trim();
                query = query.Where(x => x.c.FullName.Contains(key)
                                      || (x.c.Phone != null && x.c.Phone.Contains(key))
                                      || x.u.Username.Contains(key));
            }
            if (active.HasValue)
                query = query.Where(x => x.u.IsActive == active.Value);

            var rows = query.OrderBy(x => x.c.FullName)
                .Select(x => new CustomerRow(x.c.Id, x.c.FullName, x.c.Phone, x.u.Username,
                                             x.u.IsActive,
                                             Db.Vehicles.Count(v => v.CustomerId == x.c.Id)));

            ViewBag.Q = q;
            ViewBag.Active = active;
            return View(await PagedList<CustomerRow>.CreateAsync(rows, page, PageSize));
        }

        [HttpGet]
        public IActionResult Create() => View("Form", new CustomerForm());

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CustomerForm f)
        {
            var username = f.Username?.Trim() ?? "";
            if (username.Length == 0)
                ModelState.AddModelError(nameof(f.Username), "Nhập tên đăng nhập.");
            else if (await Db.AppUsers.AnyAsync(u => u.Username == username))
                ModelState.AddModelError(nameof(f.Username), "Tên đăng nhập đã tồn tại.");
            if (string.IsNullOrEmpty(f.Password))
                ModelState.AddModelError(nameof(f.Password), "Nhập mật khẩu ban đầu.");
            if (!ModelState.IsValid) return View("Form", f);

            var role = await Db.Roles.FirstAsync(r => r.Name == "Customer");
            var user = new AppUser { RoleId = role.Id, Username = username, IsActive = f.IsActive };
            user.PasswordHash = _hasher.HashPassword(user, f.Password!);
            var fullName = f.FullName.Trim();

            await using var tx = await Db.Database.BeginTransactionAsync();
            try
            {
                Db.AppUsers.Add(user);
                await Db.SaveChangesAsync();

                Db.Customers.Add(new Customer
                {
                    UserId = user.Id,
                    FullName = fullName,
                    Phone = string.IsNullOrWhiteSpace(f.Phone) ? null : f.Phone.Trim()
                });
                Audit($"Thêm khách hàng {fullName} (tài khoản {username})");
                await Db.SaveChangesAsync();
                await tx.CommitAsync();
            }
            catch (DbUpdateException)
            {
                ModelState.AddModelError("", "Không lưu được, vui lòng thử lại.");
                return View("Form", f);
            }
            return Done("Đã thêm khách hàng và tài khoản đăng nhập.");
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var form = await (from c in Db.Customers.AsNoTracking()
                              join u in Db.AppUsers.AsNoTracking() on c.UserId equals u.Id
                              where c.Id == id
                              select new CustomerForm
                              {
                                  Id = c.Id,
                                  FullName = c.FullName,
                                  Phone = c.Phone,
                                  Username = u.Username,
                                  IsActive = u.IsActive
                              }).FirstOrDefaultAsync();
            if (form == null) return NotFound();
            return View("Form", form);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, CustomerForm f)
        {
            var c = await Db.Customers.FirstOrDefaultAsync(x => x.Id == id);
            if (c == null) return NotFound();
            var u = await Db.AppUsers.FirstAsync(x => x.Id == c.UserId);

            f.Id = id;
            f.Username = u.Username;    // tên đăng nhập không đổi
            if (!ModelState.IsValid) return View("Form", f);

            c.FullName = f.FullName.Trim();
            c.Phone = string.IsNullOrWhiteSpace(f.Phone) ? null : f.Phone.Trim();
            u.IsActive = f.IsActive;

            var reset = !string.IsNullOrEmpty(f.Password);
            if (reset) u.PasswordHash = _hasher.HashPassword(u, f.Password!);

            Audit(reset
                ? $"Sửa khách hàng {c.FullName} và đặt lại mật khẩu"
                : $"Sửa khách hàng {c.FullName}");

            if (!await TrySaveAsync())
            {
                ModelState.AddModelError("", "Không lưu được, vui lòng thử lại.");
                return View("Form", f);
            }
            return Done("Đã cập nhật khách hàng.");
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var c = await Db.Customers.FirstOrDefaultAsync(x => x.Id == id);
            if (c == null) return NotFound();

            if (await Db.Vehicles.AnyAsync(v => v.CustomerId == id))
                return Fail("Khách còn xe đăng ký nên không thể xóa. Hãy xóa hoặc chuyển xe trước, hoặc khóa tài khoản.");

            var u = await Db.AppUsers.FirstAsync(x => x.Id == c.UserId);
            Db.Customers.Remove(c);
            Db.AppUsers.Remove(u);
            Audit($"Xóa khách hàng {c.FullName} (tài khoản {u.Username})");
            return await TrySaveAsync() ? Done("Đã xóa khách hàng.") : Fail("Không xóa được khách hàng.");
        }
    }
}