﻿using System.Globalization;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ParkingManagement.Models;
using ParkingManagement.Services;

namespace ParkingManagement.Controllers
{
    [Authorize(Roles = "Staff")]
    public class StaffController : Controller
    {
        private static readonly CultureInfo Vn = new("vi-VN");
        private readonly ParkingContext _db;
        private readonly ParkingService _service;

        public StaffController(ParkingContext db, ParkingService service)
        {
            _db = db;
            _service = service;
        }

        private static string Money(decimal v) => v.ToString("N0", Vn) + "đ";
        private static string TypeName(string t) => t == "Car" ? "Ô tô" : "Xe máy";
        private int CurrentUserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

        public IActionResult Index() => View();

        // ===================== SƠ ĐỒ Ô ĐỖ =====================
        public IActionResult SlotMap() => View();

        // AJAX: dữ liệu sơ đồ của một khu (khu đầu tiên nếu không chỉ định)
        [HttpGet]
        public async Task<IActionResult> SlotMapData(int? zoneId)
        {
            var zones = await _db.Zones.AsNoTracking()
                .OrderBy(z => z.Name)
                .Select(z => new { z.Id, z.Name })
                .ToListAsync();

            int zid = zoneId.HasValue && zones.Any(z => z.Id == zoneId.Value)
                ? zoneId.Value
                : (zones.FirstOrDefault()?.Id ?? 0);

            var slots = await _db.Slots.AsNoTracking()
                .Where(s => s.ZoneId == zid)
                .OrderBy(s => s.Code)
                .Select(s => new { s.Id, s.Code, s.Status })
                .ToListAsync();

            var ids = slots.Select(s => s.Id).ToList();
            var open = await _db.ParkingSessions.AsNoTracking()
                .Where(p => p.TimeOut == null && ids.Contains(p.SlotId))
                .Select(p => new { p.SlotId, Plate = p.Vehicle.PlateNumber, p.TimeIn })
                .ToListAsync();
            var bySlot = open.GroupBy(x => x.SlotId).ToDictionary(g => g.Key, g => g.First());

            var now = DateTime.Now;
            var items = slots.Select(s =>
            {
                bySlot.TryGetValue(s.Id, out var o);
                var dur = o == null ? TimeSpan.Zero : now - o.TimeIn;
                if (dur < TimeSpan.Zero) dur = TimeSpan.Zero;
                return new
                {
                    id = s.Id,
                    code = s.Code,
                    status = s.Status,
                    plate = o == null ? null : PlateHelper.Format(o.Plate),
                    timeIn = o == null ? null : o.TimeIn.ToString("HH:mm dd/MM"),
                    duration = o == null ? null : $"{(int)dur.TotalHours} giờ {dur.Minutes} phút"
                };
            }).ToList();

            return Json(new
            {
                zones,
                zoneId = zid,
                summary = new
                {
                    available = slots.Count(s => s.Status == "Available"),
                    occupied = slots.Count(s => s.Status == "Occupied"),
                    maintenance = slots.Count(s => s.Status == "Maintenance")
                },
                slots = items
            });
        }

        // ===================== XE VÀO / RA (AJAX) =====================

        // ô còn trống theo loại xe
        [HttpGet]
        public async Task<IActionResult> FreeSlots(string vehicleType)
        {
            var slots = await _db.Slots.AsNoTracking()
                .Where(s => s.Status == "Available" && s.Zone.VehicleType == vehicleType)
                .OrderBy(s => s.Zone.Name).ThenBy(s => s.Code)
                .Select(s => new { s.Id, label = s.Code + " - " + s.Zone.Name })
                .ToListAsync();
            return Json(slots);
        }

        // xe đang gửi
        [HttpGet]
        public async Task<IActionResult> OpenList()
        {
            var list = await _db.ParkingSessions.AsNoTracking()
                .Where(s => s.TimeOut == null)
                .OrderByDescending(s => s.TimeIn)
                .Select(s => new
                {
                    plate = s.Vehicle.PlateNumber,
                    slot = s.Slot.Code,
                    type = s.Vehicle.VehicleType,
                    timeIn = s.TimeIn
                })
                .ToListAsync();

            return Json(list.Select(x => new
            {
                plate = PlateHelper.Format(x.plate),
                x.slot,
                type = TypeName(x.type),
                timeIn = x.timeIn.ToString("HH:mm dd/MM")
            }));
        }

        // các lượt trong ngày (cả xe đã ra)
        [HttpGet]
        public async Task<IActionResult> TodayList()
        {
            var start = DateTime.Today;
            var list = await _db.ParkingSessions.AsNoTracking()
                .Where(s => s.TimeIn >= start || (s.TimeOut != null && s.TimeOut >= start))
                .OrderByDescending(s => s.TimeIn)
                .Take(50)
                .Select(s => new
                {
                    plate = s.Vehicle.PlateNumber,
                    slot = s.Slot.Code,
                    timeIn = s.TimeIn,
                    timeOut = s.TimeOut,
                    fee = s.Fee
                })
                .ToListAsync();

            return Json(list.Select(x => new
            {
                plate = PlateHelper.Format(x.plate),
                x.slot,
                timeIn = x.timeIn.ToString("HH:mm"),
                timeOut = x.timeOut == null ? "Đang gửi" : x.timeOut.Value.ToString("HH:mm"),
                fee = x.fee == null ? "-" : Money(x.fee.Value)
            }));
        }

        // ghi nhận xe vào
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> CheckIn(string plate, string vehicleType, int slotId, bool special)
        {
            var result = await _service.CheckInAsync(plate, vehicleType, slotId, CurrentUserId, special);
            return Json(new { ok = result.Ok, message = result.Message });
        }

        // tìm xe đang gửi và xem trước phí
        [HttpGet]
        public async Task<IActionResult> Lookup(string plate)
        {
            var p = await _service.PreviewCheckOutAsync(plate);
            if (!p.Found) return Json(new { found = false, message = p.Message });

            return Json(new
            {
                found = true,
                sessionId = p.SessionId,
                plate = PlateHelper.Format(p.Plate),
                slot = p.Slot,
                timeIn = p.TimeIn.ToString("HH:mm dd/MM"),
                duration = $"{(int)p.Duration.TotalHours} giờ {p.Duration.Minutes} phút",
                fee = p.FreeByPass ? "Miễn phí (vé tháng)" : Money(p.Fee)
            });
        }

        // thu phí và cho xe ra
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> CheckOut(int sessionId)
        {
            var result = await _service.CheckOutAsync(sessionId, CurrentUserId);
            return Json(new { ok = result.Ok, message = result.Message });
        }
    }
}