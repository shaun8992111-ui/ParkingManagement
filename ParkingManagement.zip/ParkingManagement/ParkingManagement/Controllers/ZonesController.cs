﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ParkingManagement.Models;
using ParkingManagement.Services;
using ParkingManagement.ViewModels;

namespace ParkingManagement.Controllers
{
    public class ZonesController : AdminBase
    {
        public ZonesController(ParkingContext db) : base(db) { }

        public async Task<IActionResult> Index(string? q, string? vehicleType, int page = 1)
        {
            var query = Db.Zones.AsNoTracking().AsQueryable();
            if (!string.IsNullOrWhiteSpace(q))
            {
                var key = q.Trim();
                query = query.Where(z => z.Name.Contains(key));
            }
            if (!string.IsNullOrWhiteSpace(vehicleType))
                query = query.Where(z => z.VehicleType == vehicleType);

            var rows = query.OrderBy(z => z.Name)
                .Select(z => new ZoneRow(z.Id, z.Name, z.VehicleType,
                                         Db.Slots.Count(s => s.ZoneId == z.Id)));

            ViewBag.Q = q;
            ViewBag.VehicleType = vehicleType;
            return View(await PagedList<ZoneRow>.CreateAsync(rows, page, PageSize));
        }

        [HttpGet]
        public IActionResult Create() => View("Form", new ZoneForm());

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ZoneForm f)
        {
            var name = f.Name?.Trim() ?? "";
            if (await Db.Zones.AnyAsync(z => z.Name == name))
                ModelState.AddModelError(nameof(f.Name), "Tên khu đã tồn tại.");
            if (!ModelState.IsValid) return View("Form", f);

            Db.Zones.Add(new Zone { Name = name, VehicleType = f.VehicleType });
            Audit($"Thêm khu đỗ {name}");
            if (!await TrySaveAsync())
            {
                ModelState.AddModelError("", "Không lưu được, vui lòng thử lại.");
                return View("Form", f);
            }
            return Done("Đã thêm khu đỗ.");
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var z = await Db.Zones.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
            if (z == null) return NotFound();
            return View("Form", new ZoneForm { Id = z.Id, Name = z.Name, VehicleType = z.VehicleType });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, ZoneForm f)
        {
            var z = await Db.Zones.FirstOrDefaultAsync(x => x.Id == id);
            if (z == null) return NotFound();

            f.Id = id;
            var name = f.Name?.Trim() ?? "";
            if (await Db.Zones.AnyAsync(x => x.Name == name && x.Id != id))
                ModelState.AddModelError(nameof(f.Name), "Tên khu đã tồn tại.");
            if (f.VehicleType != z.VehicleType && await Db.Slots.AnyAsync(s => s.ZoneId == id))
                ModelState.AddModelError(nameof(f.VehicleType), "Khu đã có ô đỗ nên không đổi được loại xe.");
            if (!ModelState.IsValid) return View("Form", f);

            z.Name = name;
            z.VehicleType = f.VehicleType;
            Audit($"Sửa khu đỗ {name}");
            if (!await TrySaveAsync())
            {
                ModelState.AddModelError("", "Không lưu được, vui lòng thử lại.");
                return View("Form", f);
            }
            return Done("Đã cập nhật khu đỗ.");
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var z = await Db.Zones.FirstOrDefaultAsync(x => x.Id == id);
            if (z == null) return NotFound();

            if (await Db.Slots.AnyAsync(s => s.ZoneId == id))
                return Fail("Khu này còn ô đỗ nên không thể xóa. Hãy xóa hoặc chuyển các ô trước.");

            Db.Zones.Remove(z);
            Audit($"Xóa khu đỗ {z.Name}");
            return await TrySaveAsync() ? Done("Đã xóa khu đỗ.") : Fail("Không xóa được khu đỗ.");
        }
    }
}