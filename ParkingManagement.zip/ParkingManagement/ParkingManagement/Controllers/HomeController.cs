using System.Diagnostics;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ParkingManagement.Models;

namespace ParkingManagement.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly ParkingContext _db;

        public HomeController(ParkingContext db)
        {
            _db = db;
        }

        public IActionResult Index()
        {
            if (User.IsInRole("Admin"))
                return RedirectToAction("Index", "Dashboard");
            if (User.IsInRole("Staff"))
                return RedirectToAction("Index", "Staff");
            return View(_db.Slots.ToList());
        }

        [AllowAnonymous]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}