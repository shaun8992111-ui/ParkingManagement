﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ParkingManagement.Dtos;
using ParkingManagement.Models;
using ParkingManagement.Services;

namespace ParkingManagement.Controllers.Api
{
    [Route("api/sessions")]
    public class SessionsApiController : ApiBase
    {
        private const int MaxPageSize = 100;

        public SessionsApiController(ParkingContext db) : base(db) { }

        // GET /api/sessions?plate=29a&open=true&date=2026-10-09&page=1&pageSize=20
        [HttpGet]
        public async Task<IActionResult> GetAll(
            string? plate, bool? open, DateTime? date, int page = 1, int pageSize = 20)
        {
            page = Math.Max(1, page);
            pageSize = Math.Clamp(pageSize, 1, MaxPageSize);

            var q = Db.ParkingSessions.AsNoTracking().AsQueryable();

            if (!string.IsNullOrWhiteSpace(plate))
            {
                var p = PlateHelper.Normalize(plate);
                q = q.Where(s => s.Vehicle.PlateNumber.Contains(p));
            }
            if (open.HasValue)
                q = open.Value ? q.Where(s => s.TimeOut == null)
                               : q.Where(s => s.TimeOut != null);
            if (date.HasValue)
            {
                var d = date.Value.Date;
                q = q.Where(s => s.TimeIn >= d && s.TimeIn < d.AddDays(1));
            }

            var total = await q.CountAsync();
            var items = await q.OrderByDescending(s => s.TimeIn)
                .Skip((page - 1) * pageSize).Take(pageSize)
                .Select(s => new SessionDto(
                    s.Id, s.Vehicle.PlateNumber, s.Vehicle.VehicleType,
                    s.Slot.Code, s.TimeIn, s.TimeOut, s.Fee))
                .ToListAsync();

            return Ok(new PagedResult<SessionDto>(items, page, pageSize, total));
        }

        // GET /api/sessions/5
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            var dto = await LoadSessionAsync(id);
            if (dto == null)
                return NotFound(new ProblemDetails
                {
                    Title = "Không tìm thấy lượt gửi xe",
                    Status = StatusCodes.Status404NotFound
                });
            return Ok(dto);
        }
    }
}