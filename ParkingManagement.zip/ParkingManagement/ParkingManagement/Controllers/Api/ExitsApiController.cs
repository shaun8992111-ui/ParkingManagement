﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ParkingManagement.Dtos;
using ParkingManagement.Models;
using ParkingManagement.Services;

namespace ParkingManagement.Controllers.Api
{
    [Route("api/exits")]
    [Authorize(Roles = "Staff")]
    public class ExitsApiController : ApiBase
    {
        private readonly ParkingService _service;

        public ExitsApiController(ParkingContext db, ParkingService service) : base(db)
        {
            _service = service;
        }

        // GET /api/exits/preview?plate=29A-12345   (xem phí, chưa thu)
        [HttpGet("preview")]
        public async Task<IActionResult> Preview(string plate)
        {
            var p = await _service.PreviewCheckOutAsync(plate);
            if (!p.Found)
                return NotFound(new ProblemDetails
                {
                    Title = "Không tìm thấy xe đang gửi",
                    Detail = p.Message,
                    Status = StatusCodes.Status404NotFound
                });

            return Ok(new
            {
                sessionId = p.SessionId,
                plate = p.Plate,
                plateDisplay = PlateHelper.Format(p.Plate),
                slot = p.Slot,
                timeIn = p.TimeIn,
                durationMinutes = (int)p.Duration.TotalMinutes,
                fee = p.Fee,
                freeByPass = p.FreeByPass
            });
        }

        // POST /api/exits   { "plate": "29A-12345" }
        [HttpPost]
        [ProducesResponseType(typeof(SessionDto), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
        public async Task<IActionResult> Create(CheckOutRequest req)
        {
            var preview = await _service.PreviewCheckOutAsync(req.Plate);
            if (!preview.Found)
                return NotFound(new ProblemDetails
                {
                    Title = "Không tìm thấy xe đang gửi",
                    Detail = preview.Message,
                    Status = StatusCodes.Status404NotFound
                });

            var result = await _service.CheckOutAsync(preview.SessionId, CurrentUserId);
            if (!result.Ok)
                return UnprocessableEntity(new ProblemDetails
                {
                    Title = "Không thể thu phí",
                    Detail = result.Message,
                    Status = StatusCodes.Status422UnprocessableEntity
                });

            return Ok(await LoadSessionAsync(preview.SessionId));
        }
    }
}