﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ParkingManagement.Dtos;
using ParkingManagement.Models;

namespace ParkingManagement.Controllers.Api
{
    [Route("api/slots")]
    public class SlotsApiController : ApiBase
    {
        public SlotsApiController(ParkingContext db) : base(db) { }

        // GET /api/slots?status=Available&vehicleType=Motorbike
        [HttpGet]
        public async Task<IActionResult> GetAll(string? status, string? vehicleType)
        {
            var q = Db.Slots.AsNoTracking().AsQueryable();
            if (!string.IsNullOrWhiteSpace(status))
                q = q.Where(s => s.Status == status);
            if (!string.IsNullOrWhiteSpace(vehicleType))
                q = q.Where(s => s.Zone.VehicleType == vehicleType);

            var list = await q.OrderBy(s => s.Zone.Name).ThenBy(s => s.Code)
                .Select(s => new SlotDto(s.Id, s.Code, s.Zone.Name, s.Zone.VehicleType, s.Status))
                .ToListAsync();

            return Ok(list);
        }
    }
}