﻿using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ParkingManagement.Dtos;
using ParkingManagement.Models;

namespace ParkingManagement.Controllers.Api
{
    [ApiController]
    [Authorize(Roles = "Staff,Admin")]
    public abstract class ApiBase : ControllerBase
    {
        protected ParkingContext Db { get; }

        protected ApiBase(ParkingContext db) { Db = db; }

        protected int CurrentUserId =>
            int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

        protected Task<SessionDto?> LoadSessionAsync(int id) =>
            Db.ParkingSessions.AsNoTracking()
              .Where(s => s.Id == id)
              .Select(s => new SessionDto(
                  s.Id, s.Vehicle.PlateNumber, s.Vehicle.VehicleType,
                  s.Slot.Code, s.TimeIn, s.TimeOut, s.Fee))
              .FirstOrDefaultAsync();
    }
}