﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ParkingManagement.Dtos;
using ParkingManagement.Models;
using ParkingManagement.Services;

namespace ParkingManagement.Controllers.Api
{
    [Route("api/entries")]
    [Authorize(Roles = "Staff")]
    public class EntriesApiController : ApiBase
    {
        private readonly ParkingService _service;

        public EntriesApiController(ParkingContext db, ParkingService service) : base(db)
        {
            _service = service;
        }

        // POST /api/entries   { "plate": "29C1-678.90", "vehicleType": "Motorbike", "slotId": 3, "special": false }
        [HttpPost]
        [ProducesResponseType(typeof(SessionDto), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status422UnprocessableEntity)]
        public async Task<IActionResult> Create(CheckInRequest req)
        {
            var result = await _service.CheckInAsync(
                req.Plate, req.VehicleType, req.SlotId, CurrentUserId, req.Special);

            if (!result.Ok)
                return UnprocessableEntity(new ProblemDetails
                {
                    Title = "Không thể ghi nhận xe vào",
                    Detail = result.Message,
                    Status = StatusCodes.Status422UnprocessableEntity
                });

            var dto = await LoadSessionAsync(result.SessionId!.Value);
            return Created($"/api/sessions/{dto!.Id}", dto);
        }
    }
}