﻿using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Localization;
using ParkingManagement.Models;

namespace ParkingManagement.Controllers
{
    public class AccountController : Controller
    {
        private readonly ParkingContext _db;
        private readonly IStringLocalizer<SharedResource> _l;
        private readonly PasswordHasher<AppUser> _hasher = new();

        public AccountController(ParkingContext db, IStringLocalizer<SharedResource> l)
        {
            _db = db;
            _l = l;
        }

        [HttpGet]
        public IActionResult Login(string? returnUrl = null)
        {
            ViewBag.ReturnUrl = returnUrl;
            return View(new LoginViewModel());
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel vm, string? returnUrl = null)
        {
            if (!ModelState.IsValid) return View(vm);

            var user = await _db.AppUsers.Include(u => u.Role)
                .FirstOrDefaultAsync(u => u.Username == vm.Username);

            if (user == null || !user.IsActive ||
                _hasher.VerifyHashedPassword(user, user.PasswordHash, vm.Password)
                    == PasswordVerificationResult.Failed)
            {
                ModelState.AddModelError("", _l["Sai tên đăng nhập hoặc mật khẩu."]);
                return View(vm);
            }

            var claims = new List<Claim>
            {
                new(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new(ClaimTypes.Name, user.Username),
                new(ClaimTypes.Role, user.Role.Name)
            };
            var identity = new ClaimsIdentity(claims,
                CookieAuthenticationDefaults.AuthenticationScheme);

            await HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                new ClaimsPrincipal(identity),
                new AuthenticationProperties { IsPersistent = vm.RememberMe });

            if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                return Redirect(returnUrl);
            return RedirectToAction("Index", "Home");
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login");
        }

        public IActionResult AccessDenied() => View();
    }
}