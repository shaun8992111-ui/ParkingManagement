using System.Globalization;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Localization;
using Microsoft.EntityFrameworkCore;
using ParkingManagement;
using ParkingManagement.Models;
using ParkingManagement.Services;

var builder = WebApplication.CreateBuilder(args);

// Tài nguyên ngôn ngữ nằm trong thư mục Resources
builder.Services.AddLocalization(o => o.ResourcesPath = "Resources");

builder.Services.AddControllersWithViews()
    .AddViewLocalization()
    .AddDataAnnotationsLocalization(o =>
        // Nhãn [Display] và ErrorMessage trong ViewModel tra cứu trong SharedResource
        o.DataAnnotationLocalizerProvider = (type, factory) => factory.Create(typeof(SharedResource)));

builder.Services.Configure<RequestLocalizationOptions>(o =>
{
    var supported = new[] { new CultureInfo("vi"), new CultureInfo("en") };
    o.DefaultRequestCulture = new RequestCulture("vi");
    o.SupportedCultures = supported;
    o.SupportedUICultures = supported;
    // Chỉ đọc ngôn ngữ từ cookie do nút VI | EN đặt
    o.RequestCultureProviders = new List<IRequestCultureProvider> { new CookieRequestCultureProvider() };
});

builder.Services.AddDbContext<ParkingContext>(o =>
    o.UseSqlServer(builder.Configuration.GetConnectionString("ParkingContext")));

builder.Services.AddScoped<ParkingService>();

builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(o =>
    {
        o.LoginPath = "/Account/Login";
        o.AccessDeniedPath = "/Account/AccessDenied";
        o.ExpireTimeSpan = TimeSpan.FromHours(8);
        o.SlidingExpiration = true;
        o.Cookie.HttpOnly = true;
        o.Cookie.SameSite = SameSiteMode.Lax;

        // Với đường dẫn /api: trả 401 hoặc 403 thay vì chuyển hướng sang trang đăng nhập
        o.Events.OnRedirectToLogin = ctx =>
        {
            if (ctx.Request.Path.StartsWithSegments("/api"))
                ctx.Response.StatusCode = StatusCodes.Status401Unauthorized;
            else
                ctx.Response.Redirect(ctx.RedirectUri);
            return Task.CompletedTask;
        };
        o.Events.OnRedirectToAccessDenied = ctx =>
        {
            if (ctx.Request.Path.StartsWithSegments("/api"))
                ctx.Response.StatusCode = StatusCodes.Status403Forbidden;
            else
                ctx.Response.Redirect(ctx.RedirectUri);
            return Task.CompletedTask;
        };
    });

var app = builder.Build();

// Băm mật khẩu cho tài khoản mẫu còn là PLACEHOLDER_HASH (chỉ để phát triển và demo)
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<ParkingContext>();
    var hasher = new PasswordHasher<AppUser>();
    foreach (var u in db.AppUsers.Where(x => x.PasswordHash == "PLACEHOLDER_HASH"))
        u.PasswordHash = hasher.HashPassword(u, "Parking@123");
    db.SaveChanges();
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseRequestLocalization();   // đặt trước UseRouting để mọi yêu cầu có ngôn ngữ đúng
app.UseRouting();

app.UseAuthentication();   // phải đứng trên UseAuthorization
app.UseAuthorization();

app.MapStaticAssets();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}")
    .WithStaticAssets();

app.Run();