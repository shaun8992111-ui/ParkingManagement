﻿using System.ComponentModel.DataAnnotations;
using ParkingManagement.Services;

namespace ParkingManagement.Dtos
{
    // ---------- Dữ liệu gửi lên ----------
    public class CheckInRequest
    {
        [Required(ErrorMessage = "Biển số là bắt buộc")]
        [StringLength(20, MinimumLength = 4, ErrorMessage = "Biển số từ 4 đến 20 ký tự")]
        public string Plate { get; set; } = "";

        [Required(ErrorMessage = "Loại xe là bắt buộc")]
        [RegularExpression("^(Motorbike|Car)$", ErrorMessage = "VehicleType phải là Motorbike hoặc Car")]
        public string VehicleType { get; set; } = "";

        [Range(1, int.MaxValue, ErrorMessage = "SlotId không hợp lệ")]
        public int SlotId { get; set; }

        // Biển đặc biệt (nước ngoài, quân đội, ngoại giao): bỏ qua kiểm tra mẫu thường
        public bool Special { get; set; }
    }

    public class CheckOutRequest
    {
        [Required(ErrorMessage = "Biển số là bắt buộc")]
        [StringLength(20, MinimumLength = 4, ErrorMessage = "Biển số từ 4 đến 20 ký tự")]
        public string Plate { get; set; } = "";
    }

    // ---------- Dữ liệu trả về ----------
    public record SlotDto(int Id, string Code, string Zone, string VehicleType, string Status);

    public record SessionDto(int Id, string Plate, string VehicleType, string Slot,
                             DateTime TimeIn, DateTime? TimeOut, decimal? Fee)
    {
        public string PlateDisplay => PlateHelper.Format(Plate);
        public bool Open => TimeOut == null;
    }

    public record PagedResult<T>(IReadOnlyList<T> Items, int Page, int PageSize, int TotalItems);
}